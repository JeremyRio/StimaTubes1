package za.co.entelect.challenge;

import za.co.entelect.challenge.command.*;
import za.co.entelect.challenge.entities.*;
import za.co.entelect.challenge.enums.PowerUps;
import za.co.entelect.challenge.enums.State;
import za.co.entelect.challenge.enums.Terrain;

import java.util.*;

import static java.lang.Math.max;

import java.security.SecureRandom;

public class Bot {
    private List<Command> directionList = new ArrayList<>();

    private Random random;
    private GameState gameState;
    private Car opponent;
    private Car myCar;
    private final static Command FIX = new FixCommand();

    private final static Command ACCELERATE = new AccelerateCommand();
    private final static Command LIZARD = new LizardCommand();
    private final static Command OIL = new OilCommand();
    private final static Command BOOST = new BoostCommand();
    private final static Command EMP = new EmpCommand();

    private final static Command TURN_RIGHT = new ChangeLaneCommand(1);
    private final static Command TURN_LEFT = new ChangeLaneCommand(-1);

    public Bot(Random random, GameState gameState) {
        this.random = random;
        this.gameState = gameState;
        this.myCar = gameState.player;
        this.opponent = gameState.opponent;

        directionList.add(TURN_RIGHT);
        directionList.add(TURN_LEFT);
    }

    public Command run() {

        int middleScore;
        int leftScore = -200;
        int rightScore = -200;
        int leftDanger = 0;
        int rightDanger = 0;
        int middleDanger = 0;
        List<Object> blocks;

        if (myCar.state == State.ACCELERATING) {
            blocks = getBlocksInFront(myCar.position.lane, myCar.position.block, myCar.speed + 2);
        } else {
            blocks = getBlocksInFront(myCar.position.lane, myCar.position.block, myCar.speed);
        }

        if (myCar.damage >= 2) {
            return FIX;
        }

        if (blocks.contains(Terrain.MUD) || blocks.contains(Terrain.WALL) || blocks.contains(Terrain.OIL_SPILL)) {
            middleDanger = getDanger(blocks);
            middleScore = getScore(blocks);
            if (myCar.position.lane != 1) {
                leftScore = getScore(
                        getBlocksInFront(myCar.position.lane - 1, myCar.position.block, myCar.speed - 1));
                leftDanger = getDanger(
                        getBlocksInFront(myCar.position.lane - 1, myCar.position.block, myCar.speed));
            }
            if (myCar.position.lane != 4) {
                rightScore = getScore(
                        getBlocksInFront(myCar.position.lane + 1, myCar.position.block, myCar.speed - 1));
                rightDanger = getDanger(
                        getBlocksInFront(myCar.position.lane + 1, myCar.position.block, myCar.speed));
            }
            if (leftDanger > 0 && rightDanger > 0 && middleDanger > 0 && hasPowerUp(PowerUps.LIZARD)) {
                return LIZARD;
            } else if (middleScore >= leftScore && middleScore >= rightScore) {
                return ACCELERATE;
            } else if (leftScore >= middleScore && leftScore >= rightScore && myCar.position.lane != 1) {
                return TURN_LEFT;
            } else if (rightScore >= middleScore && rightScore >= leftScore && myCar.position.lane != 4) {
                return TURN_RIGHT;
            }
        }

        if ((opponent.position.lane == myCar.position.lane || opponent.position.lane == myCar.position.lane - 1
                || opponent.position.lane == myCar.position.lane + 1) &&
                opponent.position.block > myCar.position.block) {
            if (hasPowerUp(PowerUps.EMP) && opponent.speed > 3) {
                return EMP;
            }
        }

        if (hasPowerUp(PowerUps.TWEET)) {
            return new TweetCommand(opponent.position.lane, opponent.position.block + opponent.speed);
        }

        if (myCar.position.lane == opponent.position.lane && opponent.position.block < myCar.position.block) {
            if (hasPowerUp(PowerUps.OIL)) {
                return OIL;
            }
        }

        if (hasPowerUp(PowerUps.BOOST) && myCar.speed <= 15 && isClearForBoost()) {
            if (myCar.damage >= 1) {
                return FIX;
            } else {
                return BOOST;
            }

        } else {
            return ACCELERATE;
        }
    }

    /**
     * Mengecek apakah terdapat suatu power up
     * yang tersedia dalam bot myCar
     */

    private Boolean hasPowerUp(PowerUps powerUpToCheck) {
        for (PowerUps powerUp : myCar.powerups) {
            if (powerUp.equals(powerUpToCheck)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Mengembalikan hasil total score dari seluruh
     * block terhadap Terrain
     */
    private int getDanger(List<Object> blocks) {
        int danger = 0;
        for (int i = 0; i < blocks.size(); i++) {
            if (blocks.get(i) == Terrain.WALL) {
                danger += 1;
            } else if (blocks.get(i) == Terrain.OIL_SPILL) {
                danger += 1;
            } else if (blocks.get(i) == Terrain.MUD) {
                danger += 1;
            }
        }
        return danger;
    }

    private int getScore(List<Object> blocks) {
        int score = 0;
        for (int i = 0; i < blocks.size(); i++) {
            if (blocks.get(i) == Terrain.WALL) {
                score -= 1000;
            } else if (blocks.get(i) == Terrain.MUD) {
                score -= 2;
            } else if (blocks.get(i) == Terrain.BOOST) {
                score += 5;
            } else if (blocks.get(i) == Terrain.OIL_SPILL) {
                score -= 2;
            } else if (blocks.get(i) == Terrain.LIZARD) {
                score += 1;
            } else if (blocks.get(i) == Terrain.EMP) {
                score += 200;
            } else if (blocks.get(i) == Terrain.OIL_POWER) {
                score += 1;
            } else if (blocks.get(i) == Terrain.TWEET) {
                score += 150;
            }
        }
        return score;
    }

    /**
     * Mengembalikan list suatu block yang dapat dihinggapi
     * oleh kecepatan masukan terhadap parameter lane
     * dengan posisi awal block berasal dari parameter block
     */
    private List<Object> getBlocksInFront(int lane, int block, int speed) {
        List<Lane[]> map = gameState.lanes;
        List<Object> blocks = new ArrayList<>();
        int startBlock = map.get(0)[0].position.block;

        Lane[] laneList = map.get(lane - 1);
        for (int i = max(block - startBlock, 0); i <= block - startBlock + speed; i++) {
            if (laneList[i] == null || laneList[i].terrain == Terrain.FINISH) {
                break;
            }

            blocks.add(laneList[i].terrain);

        }
        return blocks;
    }

    /**
     * Mengembalikan true jika 15 block di depan bot
     * tidak memiliki obstacle (mud, wall, oil spill)
     */
    private Boolean isClearForBoost() {
        // KAMUS LOKAL
        boolean isClear = true;
        List<Object> blocks = getBlocksInFront(myCar.position.lane, myCar.position.block, 15);

        // ALGORITMA
        for (int i = 0; i < blocks.size(); i++) {
            if (blocks.get(i) == Terrain.WALL || blocks.get(i) == Terrain.MUD || blocks.get(i) == Terrain.OIL_SPILL) {
                isClear = false;
            }
        }
        return isClear;
    }
}